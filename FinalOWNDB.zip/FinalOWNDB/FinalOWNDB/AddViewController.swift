//
//  AddViewController.swift
//  FinalOWNDB
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

class AddViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var addTableview: UITableView!
    
    var CountryStr = NSString()
    var PopulationStr = NSString()
    
    var DBArray = NSMutableArray()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        ViewController().addMEDDB()
        
        addTableview.registerNib(UINib(nibName: "AddTableViewCell", bundle: nil), forCellReuseIdentifier: "AddTableViewCell")

        // Do any additional setup after loading the view.
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return 1
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let myCell = tableView.dequeueReusableCellWithIdentifier("AddTableViewCell") as! AddTableViewCell
        
        myCell.countryTxt.delegate = self
        myCell.populationTxt.delegate = self
        
        myCell.countryTxt.text = CountryStr as String
        myCell.populationTxt.text = PopulationStr as String
        
        
        
        myCell.selectionStyle = .None
        return myCell
        
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {  //delegate method
        
        if textField.tag == 0 {
            
            CountryStr = textField.text!
        }
        else if(textField.tag == 1)
        {
            PopulationStr = textField.text!
        }
        
        
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {//delegate method
        
        textField.resignFirstResponder()
        
        
        return true
    }
    func inserintoDb()  {
        
        let filemgr = NSFileManager.defaultManager()
        
        let dirPaths = filemgr.URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)
        
        var databasePathnew = dirPaths[0].URLByAppendingPathComponent("mynaveengDB.sqlite").path!
        
        let NGDB = FMDatabase(path:databasePathnew as String)
        
        if NGDB.open() {
            
            //            let insertSQL = "INSERT INTO jaffadata (id, country, [population]) VALUES ('\(iDStr)', '\(CountryStr)', '\(PopulationStr)'"
            let insertSQL = "INSERT INTO JAFFADATA (country, population) VALUES ('\(CountryStr)', '\(PopulationStr)')"
            
            
            let result = NGDB.executeUpdate(insertSQL, withArgumentsInArray: nil)
            
            if !result {
                
                print("Error:\(NGDB.lastErrorMessage())")
                
            }
            else
            {
                //Do whtever you want
            }
            
            
        }
        
    }
    
    func SelectFromDB() {
        
        let filemgr = NSFileManager.defaultManager()
        let dirPaths = filemgr.URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)
        
        var databasePathnew = dirPaths[0].URLByAppendingPathComponent("mynaveengDB.sqlite").path!
        
        let NGDB = FMDatabase(path:databasePathnew as String)
        
        if NGDB.open() {
            
            let querySQl = "SELECT * FROM JAFFADATA"
            
            let resultset:FMResultSet? = NGDB.executeQuery(querySQl, withArgumentsInArray: nil)
            while resultset?.next() == true {
                
                DBArray.addObject((resultset?.resultDictionary())!)
                
                
            }
            print(DBArray)
            NGDB.close()
            
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func savedatatoDB(sender: AnyObject) {
        
        self.inserintoDb()
        self.SelectFromDB()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
