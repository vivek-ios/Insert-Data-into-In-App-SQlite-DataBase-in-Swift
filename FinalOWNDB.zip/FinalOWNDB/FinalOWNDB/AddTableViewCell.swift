//
//  AddTableViewCell.swift
//  FinalOWNDB
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

class AddTableViewCell: UITableViewCell {

    @IBOutlet var populationTxt: UITextField!
    @IBOutlet var countryTxt: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
