//
//  GetViewController.swift
//  FinalOWNDB
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

class GetViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {

    @IBOutlet var DbTableview: UITableView!
    
    var DbDataArray = NSMutableArray()
    
    var database: FMDatabase? = nil

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.GetData()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func GetData() {
        
        DbDataArray = GetDataFromDB()
        
        DbTableview.reloadData()
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
        
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return DbDataArray.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell:GetTableViewCell = tableView.dequeueReusableCellWithIdentifier("GetTableViewCell") as! GetTableViewCell
        let repo:ModelData = DbDataArray.objectAtIndex(indexPath.row) as! ModelData
        cell.countryTxt.text = repo.Country
        cell.populationTxt.text = repo.Population
        
        return cell
        
        
    }
    func GetDataFromDB()  -> NSMutableArray{
        
        let marrEmergencyContactsInfo : NSMutableArray = NSMutableArray()

        let MEDDB = FMDatabase(path:databaseMedical as String)
               if MEDDB.open() {
                let resultSet: FMResultSet! = MEDDB.executeQuery("SELECT country, population FROM JAFFADATA", withArgumentsInArray: nil)
                if (resultSet != nil) {
                    while resultSet.next() {
                        let Repo : ModelData = ModelData()
                        let Country = resultSet.stringForColumn("country")
                        let Population: String = resultSet.stringForColumn("population")
                        
                        Repo.Country = Country != "" ? Country : ""
                        Repo.Population = Population != "" ? Population : ""
                        
                        marrEmergencyContactsInfo.addObject(Repo)
                   }
            }
        }
        return marrEmergencyContactsInfo
    }


}
class ModelData: NSObject
{
    var Country: String = String()
    var Population: String = String()
}
