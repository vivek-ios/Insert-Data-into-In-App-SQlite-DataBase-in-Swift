//
//  GetTableViewCell.swift
//  FinalOWNDB
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

class GetTableViewCell: UITableViewCell {

    @IBOutlet var populationTxt: UILabel!
    @IBOutlet var countryTxt: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
