//
//  ViewController.swift
//  FinalOWNDB
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

var databaseMedical = NSString()

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.addMEDDB()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func addMEDDB() {
        let filemngr = NSFileManager.defaultManager()
        let filepaths = filemngr.URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)
        
        databaseMedical = filepaths[0].URLByAppendingPathComponent("mynaveengDB.sqlite").path!
        
        if !(filemngr.fileExistsAtPath(databaseMedical as String)) {
            
            
            let MEDDB = FMDatabase(path:databaseMedical as String)
            
            if MEDDB == nil {
                
                print("ErrorDB:\(MEDDB.lastErrorMessage())")
            }
            if MEDDB.open() {
                
                let sqlsgmnt = "CREATE TABLE IF NOT EXISTS JAFFADATA (COUNTRY TEXT, POPULATION TEXT)"
                
                if !MEDDB.executeStatements(sqlsgmnt) {
                    
                    print("ErrorSt:\(MEDDB.lastErrorMessage())")
                }
                
                MEDDB.close()
            }
                
            else
            {
                print("ErrorSt:\(MEDDB.lastErrorMessage())")
                
            }
        }
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

